<?php

$conn = mysqli_connect("localhost","root","","phpcrud"); // Here is the first parameter is your port address, second one is your default user  & third one is for your password of database user and fourth one is your database that want to connect.


?>